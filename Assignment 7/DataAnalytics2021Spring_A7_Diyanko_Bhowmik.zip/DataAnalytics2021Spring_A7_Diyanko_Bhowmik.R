library(ggplot2)
library(rlang)
library(glue)
library(tibble)
library(dplyr)
library(lubridate)
library(ggplot2)
library(factoextra)
library(usethis)
library(tidyverse)
library(randomForest)

white_wine = read.table("http://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/winequality-white.csv", sep = ";", header = T)
red_wine = read.table("http://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/winequality-red.csv", sep = ";", header = T)

white_wine$color = "white"
red_wine$color = "red"

data = rbind(red_wine,white_wine)

qplot(x = color, y = density, data = data, geom = "boxplot")
qplot(x = color, y = pH, data = data, geom = "boxplot")
qplot(x = color, y = alcohol, data = data, geom = "boxplot")

shapiro.test(sample(data$quality,5000,replace = FALSE,prob = NULL))
boxplot(data$quality)

str(data)
data1 = subset(data,select = -c(color))
str(data1)
data1$quality = as.numeric(data1$quality)
cor(data1)
heatmap(cor(data1))

#KMeans

library(gmodels)
fviz_nbclust(subset(data1,select = -c(quality)), kmeans, method = "wss") + geom_vline(xintercept = 4, linetype = 5) + labs(subtitle = "Elbow method")

set.seed(123)

km.res = kmeans(subset(data1,select = -c(quality)), 4, nstart = 50)
print(km.res$cluster)
data1$cluster = print(km.res$cluster)
CrossTable(y = data1$quality, x = data1$cluster)

#Randeom Forest

data1$quality = as.factor(data1$quality)
training_set1 = data1[1:4872,]
validation_set1 = data1[4873:6497,]
wine_randomforest = randomForest(quality ~ .,data = training_set1)
wine_randomforest
prediction1 = predict(wine_randomforest,validation_set1[,1:11])
prediction1

#kNN

library(class)
library(gmodels)
training_set2 = data1[1:4872,]
validation_set2 = data1[4873:6497,]

train_wine_target = data1[1:4872,12]
test_wine_target = data1[4873:6497,12]

prediction2 = knn(train = training_set2, test = validation_set2,cl = train_wine_target, k = 10)

CrossTable(x = test_wine_target, y = prediction2)

#Absenteeism

require(dplyr)
require(ggplot2)
require(randomForest)
require(e1071)
absenteeism_original = read.csv(file.choose(), header = T, sep = ";")

absenteeism_data = absenteeism_original 

absenteeism_data2 = absenteeism_data %>% select(ID, Transportation.expense, Distance.from.Residence.to.Work, Service.time, Age, Education, Son, Social.drinker, Social.smoker, Pet, Weight, Height, Body.mass.index) %>% distinct()

absenteeism_data3 = absenteeism_data %>% select(ID, Reason.for.absence, Month.of.absence, Day.of.the.week, Seasons, Work.load.Average.day, Hit.target, Disciplinary.failure,Absenteeism.time.in.hours, )

absenteeism_data2 %>% mutate(Education = as.factor(Education), Age = as.factor(Age)) %>% ggplot(mapping = aes(x = Age, fill = Education)) + geom_bar() + scale_fill_manual(labels = c("High school", "Graduate", "Post-graduate", "Master and Doctor"), values = c("aquamarine", "aquamarine3", "cadetblue4", "darkslategrey"))

table(absenteeism_data3$ID)
table(absenteeism_data3[which(absenteeism_data3$ID == 3),]$Reason.for.absence)

#Random Forest

rf_data = absenteeism_data[which(absenteeism_data$ID !=  3), ] %>% select(Reason.for.absence, Month.of.absence, Day.of.the.week, Distance.from.Residence.to.Work, Age, Disciplinary.failure, Education, Son, Social.drinker, Social.smoker, Pet, Absenteeism.time.in.hours)

rf_data$Reason.for.absence = as.factor(rf_data$Reason.for.absence)

rf.partial = rf_data[rf_data$Reason.for.absence %in% c(0,1,6,7,10,11,12,13,14,18,19,22,23,25,26,27,28),]
rf.partial$Reason.for.absence = as.factor(as.numeric(rf.partial$Reason.for.absence))

rf.sample = ceiling(.7 * nrow(rf.partial))
rf.samp_indices = sample(nrow(rf.partial), rf.sample)
rf.train = rf.partial[rf.samp_indices,]
rf.test = rf.partial[-rf.samp_indices,]

rf.model = randomForest(Reason.for.absence ~ ., data = rf.train, mtry = 3, importance = TRUE)
rf.predict = predict(rf.model, rf.test[,names(rf.test)!="Reason.for.absence"])
table(rf.test$Reason.for.absence, rf.predict)
rf.acc = mean(rf.test$Reason.for.absence == rf.predict)

#Regression

absenteeism_data2$avg_abs_time = NA
for (i in absenteeism_data2$ID){absenteeism_data2[which(absenteeism_data2$ID == i),"avg_abs_time"] = absenteeism_data3[which(absenteeism_data3$ID == i),"Absenteeism.time.in.hours"] %>% sapply(as.numeric) %>% mean()
}

distance_reg = lm(avg_abs_time ~ Distance.from.Residence.to.Work, data = absenteeism_data2)
plot(avg_abs_time ~ Distance.from.Residence.to.Work, data = absenteeism_data2, xlab = "Distance from residence to work", ylab = "Average Absenteeism Time")

abline(distance_reg)
summary(distance_reg)

#SVM

data_svm = absenteeism_data %>% select(ID,Reason.for.absence, Month.of.absence,Day.of.the.week,Age,Education,Social.drinker,Disciplinary.failure)

data_svm$Disciplinary.failure = as.factor(data_svm$Disciplinary.failure)

sample = ceiling(.75 * nrow(data_svm))
svm_sample = sample(nrow(data_svm), sample)
train_data_svm = data_svm[svm_sample,]
test_data_svm = data_svm[-svm_sample,]

svm.model = svm(Disciplinary.failure ~ ., data = train_data_svm, kernel = "radial")

svm.tune = tune(svm, Disciplinary.failure ~ ., data = train_data_svm, kernel = "radial", ranges = list(cost = c(.1,.25,.5,1,2,3,4,5,7,10)))

summary(svm.tune)

ggplot(data = NULL, mapping = aes(x = svm.tune$performances$cost, y = svm.tune$performances$error)) + geom_line() + labs(title = "Cross Validation on Absenteeism Radial SVM", x = "Cost")
model_svm = svm.tune$best.model

predicted_svm = predict(model_svm, test_data_svm[,names(test_data_svm)!=  "Disciplinary.failure"])
table(test_data_svm$Disciplinary.failure,predicted_svm)
mean(predicted_svm == test_data_svm$Disciplinary.failure)